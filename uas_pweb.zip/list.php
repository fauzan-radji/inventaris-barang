<?php

include "utils.php";

$current_page = 1;
if (isset($_GET['page'])) $current_page = (int)$_GET['page'];
$records_per_page = env("records_per_page", 5);

$daftar_barang = read("barang", $records_per_page, ($current_page - 1) * $records_per_page);
$total_barang = countRow("barang");
$max_page = ceil($total_barang / $records_per_page);
$x = 2;
$error = getError();
$success = getSuccess();

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Daftar Barang</title>

  <?php include 'partials/css.php' ?>

  <link rel="stylesheet" href="css/list.css">
</head>

<body>
  <?php include 'partials/navigasi.php' ?>

  <div class="container">
    <div class="row">
      <?php if ($error) : ?>
        <div class="col">
          <div class="alert bg-danger"><?= $error ?></div>
        </div>
      <?php endif; ?>

      <?php if ($success) : ?>
        <div class="col">
          <div class="alert bg-success"><?= $success ?></div>
        </div>
      <?php endif; ?>
    </div>

    <div class="row">
      <div class="col">
        <h2>DATA BARANG</h2>
      </div>
    </div>

    <div class="row">
      <div class="col">
        <label for="modal-radio-ubah" class="btn btn-primary">Tambah Data Barang</label>
      </div>
    </div>

    <div class="row">
      <div class="col">
        <span>Menampilkan <?= count($daftar_barang) ?> dari <?= $total_barang ?> data</span>
      </div>
    </div>

    <div class="pagination">
      <a href="list.php?page=<?= $current_page - 1 ?>" class="prev<?= ($current_page > 1) ? '' : ' disabled' ?>">&laquo;</a>

      <?php for ($i = 1; $i <= min($x, $current_page - 1); $i++) : ?>
        <a href="list.php?page=<?= $i ?>"><?= $i ?></a>
      <?php endfor ?>

      <?php if ($current_page > $x + 1) : ?>
        <span>...</span>
      <?php endif; ?>

      <span class="current"><?= $current_page ?></span>

      <?php if ($current_page < $max_page - $x) : ?>
        <span>...</span>
      <?php endif; ?>

      <?php for ($i = max($current_page + 1, $max_page - $x + 1); $i < $max_page + 1; $i++) : ?>
        <a href="list.php?page=<?= $i ?>"><?= $i ?></a>
      <?php endfor; ?>

      <a href="list.php?page=<?= $current_page + 1 ?>" class="next<?= ($current_page < $total_barang / $records_per_page) ? '' : ' disabled' ?>">&raquo;</a>
    </div>

    <div class="row justify-content-center">
      <?php foreach ($daftar_barang as $barang) : ?>
        <div class="col-12 col-md-6 col-lg-4">
          <div class="card px-3 py-2">
            <div class="card-header">
              <h5 class="card-title"><?= $barang['nama']; ?></h5>
              <h6 class="card-subtitle text-muted">Merk: <?= $barang['merk']; ?></h6>
            </div>
            <div class="card-body d-flex justify-content-between">
              <p class="card-text">Jumlah: <?= $barang['jumlah']; ?></p>
              <p class="card-text">Rp. <?= number_format($barang['harga'], 2, ",", "."); ?></p>
            </div>
            <div class="card-footer">
              <label for="modal-radio-<?= $barang['id'] ?>" class="btn btn-secondary">Edit</label>
              <a href="delete.php?id=<?= $barang['id'] ?>" onclick="return confirm('Yakin ingin menghapus data <?= $barang['nama']; ?>')" class="btn btn-danger">Hapus</a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <input type="radio" class="modal-radio" name="modal-radio" id="modal-radio-close">

  <div class="modal-container position-fixed">
    <div class="container h-100">
      <div class="row align-items-center justify-content-center position-relative h-100">
        <!-- Modal Tambah -->
        <div class="col-12 col-md-8 position-absolute">
          <input type="radio" class="modal-radio" name="modal-radio" id="modal-radio-ubah">
          <div class="modal">
            <div class="modal-header d-flex justify-content-between">
              <h2>Tambah Barang</h2>
              <label class="btn btn-outline-danger" for="modal-radio-close">&times;</label>
            </div>

            <div class="modal-body">
              <form method="post" action="create.php" class="form">
                <div class="mb-3">
                  <label class="form-label" for="nama-ubah">Nama Barang</label>
                  <input type="text" class="form-control" name="nama" id="nama-ubah">
                </div>

                <div class="mb-3">
                  <label class="form-label" for="merk-ubah">Merk Barang</label>
                  <input type="text" class="form-control" name="merk" id="merk-ubah">
                </div>

                <div class="mb-3">
                  <label class="form-label" for="jumlah-ubah">Jumlah Barang</label>
                  <input type="number" class="form-control" name="jumlah" id="jumlah-ubah">
                </div>

                <div class="mb-3">
                  <label class="form-label" for="harga-ubah">Harga Satuan</label>
                  <input type="number" class="form-control" name="harga" step="0.01" id="harga-ubah">
                </div>

                <button class="btn btn-primary" type="submit" name="submit">Simpan</button>
                <label class="btn btn-secondary" for="modal-radio-close">Batal</label>
              </form>
            </div>
          </div>
        </div>

        <!-- Modal Ubah -->
        <?php foreach ($daftar_barang as $barang) : ?>
          <div class="col-12 col-md-8 position-absolute">
            <input type="radio" class="modal-radio" name="modal-radio" id="modal-radio-<?= $barang['id'] ?>">
            <div class="modal">
              <div class="modal-header d-flex justify-content-between">
                <h2>Ubah Data</h2>
                <label class="btn btn-outline-danger" for="modal-radio-close">&times;</label>
              </div>

              <div class="modal-body">
                <form method="post" action="update.php" class="form">
                  <input type="hidden" name="id" value="<?= $barang['id'] ?>">

                  <div class="mb-3">
                    <label class="form-label" for="nama<?= $barang['id'] ?>">Nama Barang</label>
                    <input class="form-control" type="text" name="nama" id="nama<?= $barang['id'] ?>" value="<?= $barang["nama"] ?>">
                  </div>

                  <div class="mb-3">
                    <label class="form-label" for="merk<?= $barang['id'] ?>">Merk Barang</label>
                    <input class="form-control" type="text" name="merk" id="merk<?= $barang['id'] ?>" value="<?= $barang["merk"] ?>">
                  </div>

                  <div class="mb-3">
                    <label class="form-label" for="jumlah<?= $barang['id'] ?>">Jumlah Barang</label>
                    <input class="form-control" type="number" name="jumlah" id="jumlah<?= $barang['id'] ?>" value="<?= $barang["jumlah"] ?>">
                  </div>

                  <div class="mb-3">
                    <label class="form-label" for="harga<?= $barang['id'] ?>">Harga Satuan</label>
                    <input class="form-control" type="number" name="harga" step="0.01" id="harga<?= $barang['id'] ?>" value="<?= $barang["harga"] ?>">
                  </div>

                  <button class="btn btn-primary" type="submit" name="submit">Simpan</button>
                  <label class="btn btn-secondary" for="modal-radio-close">Batal</label>
                </form>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

  </div>

</body>

</html>