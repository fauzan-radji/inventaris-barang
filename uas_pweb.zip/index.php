<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Beranda</title>

  <?php include 'partials/css.php' ?>
  <!-- <link rel="stylesheet" href="css/index.css"> -->
</head>

<body>
  <?php include 'partials/navigasi.php' ?>

  <div class="container">
    <header>
      <h1>Toko Serba Guna</h1>
    </header>

    <main>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis magni dicta et. Eum voluptatem in, non nihil inventore, animi distinctio at aspernatur, ullam repudiandae minima? Itaque voluptatum repellendus delectus odit?</p>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Et saepe dolor hic deserunt, laudantium maxime ad odio accusantium voluptatum quasi porro harum maiores, cumque deleniti mollitia numquam vitae praesentium voluptates tempora! Quae dolor laboriosam explicabo vel ipsam reiciendis eaque. Placeat odio optio veritatis, nemo laboriosam mollitia impedit, voluptatem consequuntur quia minima dolores! Modi nostrum repellendus sunt veniam fugiat reprehenderit consequatur accusamus quasi, harum natus, delectus cupiditate excepturi non? Tempora, earum.</p>
    </main>
  </div>
</body>

</html>