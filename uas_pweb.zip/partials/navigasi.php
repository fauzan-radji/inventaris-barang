<nav class="my-4">
  <a href="index.php">Beranda</a>
  <a href="list.php">Daftar Barang</a>
</nav>