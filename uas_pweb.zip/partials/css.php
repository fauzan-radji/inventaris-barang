<!-- Font -->
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,600;1,400;1,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/reset.css">
<link rel="stylesheet" href="css/colors.css">
<link rel="stylesheet" href="css/navigasi.css">
<link rel="stylesheet" href="css/components.css">
<link rel="stylesheet" href="css/modal.css">

<!-- Media Queries -->
<link rel="stylesheet" href="css/media/default.css">
<link rel="stylesheet" href="css/media/small.css">
<link rel="stylesheet" href="css/media/medium.css">
<link rel="stylesheet" href="css/media/large.css">
<link rel="stylesheet" href="css/media/x-large.css">