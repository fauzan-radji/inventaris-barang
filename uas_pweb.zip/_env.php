<?php
const ENV = [
  "db_host" => "localhost",
  "db_user" => "root",
  "db_pass" => "root",
  "db_name" => "uas_pweb",

  "records_per_page" => 9
];
